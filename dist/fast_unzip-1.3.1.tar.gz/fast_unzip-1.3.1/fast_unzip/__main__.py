from .fast_unzip import main

# entry point
if __name__ == '__main__':
    main()
