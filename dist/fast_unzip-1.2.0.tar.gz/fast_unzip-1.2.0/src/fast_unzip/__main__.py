from fast_unzip import fast_unzip

# entry point
if __name__ == '__main__':
    fast_unzip.main()
